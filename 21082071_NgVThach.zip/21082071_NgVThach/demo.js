//bai1

// Data 1
let WeightMark = 78;
let heightMark = 1.69;
let WeightJohn = 92;
let heightJohn = 1.95;

// Data 2
let WeightMark2 = 95;
let heightMark2 = 1.88;
let WeightJohn2 = 85;
let heightJohn2 = 1.76;

//data1
let BMIMark = WeightMark / (heightMark ** 2);
let BMIJohn = WeightJohn / (heightJohn ** 2);

// data2
let BMIMark2 = WeightMark2 / (heightMark2 ** 2);
let BMIJohn2 = WeightJohn2 / (heightJohn2 ** 2);

// Boolean 
let markHigherBMI1 = BMIMark > BMIJohn;
let markHigherBMI2 = BMIMark2 > BMIJohn2;

// Output  Data 1
console.log('Data 1:');
console.log(`Mark's BMI: ${BMIMark.toFixed(2)}, John's BMI: ${BMIJohn.toFixed(2)}`);
console.log(`Does Mark have a higher BMI than John? ${markHigherBMI1}`);

// Output  Data 2
console.log('Data 2:');
console.log(`Mark's BMI: ${BMIMark2.toFixed(2)}, John's BMI: ${BMIJohn2.toFixed(2)}`);
console.log(`Does Mark have a higher BMI than John? ${markHigherBMI2}`);



//bai2
// Data 1 Output
console.log('Data 1:');
if (BMIMark > BMIJohn) {
    console.log(`Mark's BMI (${BMIMark.toFixed(2)}) is higher than John's (${BMIJohn.toFixed(2)})!`);
} else {
    console.log(`John's BMI (${BMIJohn.toFixed(2)}) is higher than Mark's (${BMIMark.toFixed(2)})!`);
}

// Data 2 Output
console.log('Data 2:');
if (BMIMark2 > BMIJohn2) {
    console.log(`Mark's BMI (${BMIMark2.toFixed(2)}) is higher than John's (${BMIJohn2.toFixed(2)})!`);
} else {
    console.log(`John's BMI (${BMIJohn2.toFixed(2)}) is higher than Mark's (${BMIMark2.toFixed(2)})!`);
}

//bai3
// Data 1
const dolphinsScores = [96, 108, 89];
const koalasScores = [88, 91, 110];

// Calculate average scores
const averageDolphins = (dolphinsScores[0] + dolphinsScores[1] + dolphinsScores[2]) / 3;
const averageKoalas = (koalasScores[0] + koalasScores[1] + koalasScores[2]) / 3;

console.log("Dolphins average: " + averageDolphins);
console.log("Koalas average: " + averageKoalas);


if (averageDolphins > averageKoalas) {
    console.log("Dolphins win the trophy!");
} else if (averageKoalas > averageDolphins) {
    console.log("Koalas win the trophy!");
} else {
    console.log("It's a draw!");
}



if (averageDolphins > averageKoalas && averageDolphins >= 100) {
    console.log("Dolphins win the trophy!");
} else if (averageKoalas > averageDolphins && averageKoalas >= 100) {
    console.log("Koalas win the trophy!");
} else if (averageDolphins === averageKoalas && averageDolphins >= 100 && averageKoalas >= 100) {
    console.log("It's a draw!");
} else {
    console.log("No team wins the trophy.");
}



if (averageDolphins > averageKoalas && averageDolphins >= 100) {
    console.log("Dolphins win the trophy!");
} else if (averageKoalas > averageDolphins && averageKoalas >= 100) {
    console.log("Koalas win the trophy!");
} else if (averageDolphins === averageKoalas && averageDolphins >= 100 && averageKoalas >= 100) {
    console.log("It's a draw!");
} else {
    console.log("No team wins the trophy.");
}


if (averageDolphins > averageKoalas && averageDolphins >= 100) {
    console.log("Dolphins win the trophy!");
} else if (averageKoalas > averageDolphins && averageKoalas >= 100) {
    console.log("Koalas win the trophy!");
} else if (averageDolphins === averageKoalas && averageDolphins >= 100 && averageKoalas >= 100) {
    console.log("It's a draw!");
} else {
    console.log("No team wins the trophy.");
}